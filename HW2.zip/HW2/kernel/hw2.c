#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/list.h>
#include <linux/syscalls.h>

asmlinkage long sys_hello(void) {
    printk("Hello, World!\n");
    return 0;
}
asmlinkage long sys_set_weight(int weight){
    if (weight < 0){
        return -EINVAL;
    }
    struct task_struct *current_process;
    current_process=current;
    current_process->weight=weight;
    return 0;
}

asmlinkage long sys_get_weight(void){
    struct task_struct *current_process = current;
    return (long)current_process->weight;
}

asmlinkage long sys_get_ancestor_sum(void){
    long sum=0;
    struct task_struct *current_process = current;
    sum+=current->weight;
    while (current_process->pid!=1 && current_process->real_parent!=current_process) {
        current_process=current_process->real_parent;
        sum+=current_process->weight;
    }
    return sum;
}
pid_t get_heaviest_descendant_rec(struct task_struct * task, pid_t o_pid){
    if (list_empty(&(task->children))){
        return task->pid;
    }
    struct task_struct *temp;
    struct list_head *list;
    pid_t curr_pid;
    int heaviest_weight = -1;
    pid_t heaviest_pid = -1;

    if (task->pid == o_pid) {
        list_for_each(list, &(task->children)) {
            temp = list_entry(list, struct task_struct, sibling);
            if (temp->weight > heaviest_weight || (temp->weight == heaviest_weight && temp->pid < heaviest_pid)) {
                heaviest_weight = temp->weight;
                heaviest_pid = temp->pid;
            }
        }
    }
    else{
        heaviest_weight = task->weight;
        heaviest_pid=task->pid;
    }
    list_for_each(list,&(task->children)){
        temp=list_entry(list, struct task_struct,sibling);
        curr_pid=get_heaviest_descendant_rec(temp, o_pid);
        if ((find_task_by_vpid(curr_pid)->weight)>heaviest_weight || ((find_task_by_vpid(curr_pid)->weight)==heaviest_weight && curr_pid<heaviest_pid)){
            heaviest_weight=find_task_by_vpid(curr_pid)->weight;
            heaviest_pid=curr_pid;
        }
    }
    return heaviest_pid;
}

asmlinkage long sys_get_heaviest_descendant(void){
	struct task_struct *current_process = current;
    if (list_empty(&(current_process->children))!=0){
	return -ECHILD;
    }
    return (long)get_heaviest_descendant_rec(current_process, current_process->pid);
}

